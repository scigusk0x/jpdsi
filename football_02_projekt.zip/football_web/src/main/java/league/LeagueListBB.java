package league;

//import java.util.HashMap;
import java.util.List;
//import java.util.Map;

import jakarta.inject.Inject;
import jakarta.inject.Named;
import jakarta.enterprise.context.RequestScoped;
import jakarta.ejb.EJB;
import jakarta.faces.context.ExternalContext;
//import jakarta.faces.context.FacesContext;
import jakarta.faces.context.Flash;
//import jakarta.servlet.http.HttpSession;

import dao.LeagueDAO;
import entities.League;

@Named
@RequestScoped
public class LeagueListBB {
	private static final String PAGE_LEAGUE_EDIT = "leagueEdit?faces-redirect=true";
	private static final String PAGE_STAY_AT_THE_SAME = null;

	private String name;
		
	@Inject
	ExternalContext extcontext;
	
	@Inject
	Flash flash;
	
	@EJB
	LeagueDAO leagueDAO;
		
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<League> getFullList(){
		return leagueDAO.getFullList();
	}

	public String newLeague(){
		League league = new League();
		
		//1. Pass object through session
		//HttpSession session = (HttpSession) extcontext.getSession(true);
		//session.setAttribute("league", league);
		
		//2. Pass object through flash	
		flash.put("league", league);
		
		return PAGE_LEAGUE_EDIT;
	}

	public String editLeague(League league){
		//1. Pass object through session
		//HttpSession session = (HttpSession) extcontext.getSession(true);
		//session.setAttribute("league", league);
		
		//2. Pass object through flash 
		flash.put("league", league);
		
		return PAGE_LEAGUE_EDIT;
	}

	public String deleteLeague(League league){
		leagueDAO.remove(league);
		return PAGE_STAY_AT_THE_SAME;
	}
}
