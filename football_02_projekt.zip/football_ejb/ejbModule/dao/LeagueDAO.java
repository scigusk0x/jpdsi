package dao;

import java.util.List;

import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import entities.League;

//DAO - Data Access Object for Person entity
//Designed to serve as an interface between higher layers of application and data.
//Implemented as stateless Enterprise Java bean - server side code that can be invoked even remotely.

@Stateless
public class LeagueDAO {
	private final static String UNIT_NAME = "footballPU";

	// Dependency injection (no setter method is needed)
	@PersistenceContext(unitName = UNIT_NAME)
	protected EntityManager em;

	public void create(League league) {
		em.persist(league);
	}

	public League merge(League league) {
		return em.merge(league);
	}

	public void remove(League league) {
		em.remove(em.merge(league));
	}

	public League find(Object id) {
		return em.find(League.class, id);
	}

	public List<League> getFullList() {
		List<League> list = null;

		Query query = em.createQuery("select l from League l");

		try {
			list = query.getResultList();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return list;
	}
}
