package com.jsfcourse.calc;

import jakarta.inject.Inject;
import jakarta.inject.Named;
import jakarta.enterprise.context.RequestScoped;
import jakarta.enterprise.context.SessionScoped;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;

@Named
@RequestScoped
//@SessionScoped
public class KredBB {
	private String kwota;
	private String lata;
	private String procent;
	
	private Double rata;
	
	@Inject
	FacesContext ctx;
	
	public String getKwota() {
		return kwota;
	}
	
	public void setKwota(String kwota) {
		this.kwota = kwota;
	}
	
	public String getLata() {
		return lata;
	}
	
	public void setLata(String lata) {
		this.lata = lata;
	}
	
	public String getProcent() {
		return procent;
	}
	
	public void setProcent(String procent) {
		this.procent = procent;
	}
	
	public Double getRata() {
		return rata;
	}
	
	public void setRata(Double rata) {
		this.rata = rata;
	}
	
	public boolean doTheMath() {
		try {
			double kwota = Double.parseDouble(this.kwota);
			double lata = Double.parseDouble(this.lata);
			double procent = Double.parseDouble(this.procent);
			
			rata = kwota / (lata * 12);
			rata *= (1 + procent / 100);
			
			ctx.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Operacja wykonana poprawnie", null));
			return true;
		}
		catch (Exception e){
			ctx.addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, "Błąd podczas przetwarzania parametrów", null));
			return false;
		}
	}

	// Go to "showresult" if ok
	public String calc() {
		if (doTheMath()) {
			return "showresult";
		}
		return null;
	}

	// Put result in messages on AJAX call
	public String calc_AJAX() {
		if (doTheMath()) {
			ctx.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Rata: " + rata, null));
		}
		return null;
	}

	public String info() {
		return "info";
	}
}
