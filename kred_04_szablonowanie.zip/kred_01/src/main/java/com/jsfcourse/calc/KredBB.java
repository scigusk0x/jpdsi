package com.jsfcourse.calc;

import jakarta.inject.Inject;
import jakarta.inject.Named;
import jakarta.enterprise.context.RequestScoped;
//import jakarta.enterprise.context.SessionScoped;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;

@Named
@RequestScoped
//@SessionScoped
public class KredBB {
	private Double kwota;
	private Integer lata;
	private Double procent;
	
	private Double rata;
	
	@Inject
	FacesContext ctx;
	
	public Double getKwota() {
		return kwota;
	}
	
	public void setKwota(Double kwota) {
		this.kwota = kwota;
	}
	
	public Integer getLata() {
		return lata;
	}
	
	public void setLata(Integer lata) {
		this.lata = lata;
	}
	
	public Double getProcent() {
		return procent;
	}
	
	public void setProcent(Double procent) {
		this.procent = procent;
	}
	
	public Double getRata() {
		return rata;
	}
	
	public void setRata(Double rata) {
		this.rata = rata;
	}
	
	public boolean doTheMath() {
		rata = this.kwota / (this.lata * 12);
		rata *= (1 + this.procent / 100);
		
		ctx.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Operacja wykonana poprawnie", null));
		return true;
	}

	// Go to "showresult" if OK
	public String calc() {
		if (doTheMath()) {
			return "showresult";
		}
		return null;
	}

	// Put result in messages on AJAX call
	public String calc_AJAX() {
		if (doTheMath()) {
			ctx.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Rata: " + rata, null));
		}
		return null;
	}

	public String info() {
		return "info";
	}
}
