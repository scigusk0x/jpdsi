package jpa_football;

import java.io.Serializable;
import jakarta.persistence.*;


/**
 * The persistent class for the favourite_team database table.
 * 
 */
@Entity
@Table(name="favourite_team")
@NamedQuery(name="FavouriteTeam.findAll", query="SELECT f FROM FavouriteTeam f")
public class FavouriteTeam implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;

	@Column(name="team_id")
	private int teamId;

	@Column(name="user_id")
	private int userId;

	public FavouriteTeam() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getTeamId() {
		return this.teamId;
	}

	public void setTeamId(int teamId) {
		this.teamId = teamId;
	}

	public int getUserId() {
		return this.userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

}