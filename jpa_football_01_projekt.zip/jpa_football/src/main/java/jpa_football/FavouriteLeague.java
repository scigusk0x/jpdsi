package jpa_football;

import java.io.Serializable;
import jakarta.persistence.*;


/**
 * The persistent class for the favourite_league database table.
 * 
 */
@Entity
@Table(name="favourite_league")
@NamedQuery(name="FavouriteLeague.findAll", query="SELECT f FROM FavouriteLeague f")
public class FavouriteLeague implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;

	@Column(name="league_id")
	private int leagueId;

	@Column(name="user_id")
	private int userId;

	public FavouriteLeague() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getLeagueId() {
		return this.leagueId;
	}

	public void setLeagueId(int leagueId) {
		this.leagueId = leagueId;
	}

	public int getUserId() {
		return this.userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

}