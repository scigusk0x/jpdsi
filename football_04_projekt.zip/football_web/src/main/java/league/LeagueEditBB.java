package league;

import java.io.IOException;
import java.io.Serializable;

import jakarta.ejb.EJB;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;
import jakarta.faces.context.Flash;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
//import jakarta.servlet.http.HttpSession;

import dao.LeagueDAO;
import entities.League;

@Named
@ViewScoped
public class LeagueEditBB implements Serializable {
	private static final long serialVersionUID = 1L;

	private static final String PAGE_LEAGUE_LIST = "/pages/user/leagueList?faces-redirect=true";
	private static final String PAGE_STAY_AT_THE_SAME = null;

	private League league = new League();
	private League loaded = null;

	@EJB
	LeagueDAO leagueDAO;

	@Inject
	FacesContext context;

	@Inject
	Flash flash;

	public League getLeague() {
		return league;
	}

	public void onLoad() throws IOException {
		// 1. load league passed through session
		// HttpSession session = (HttpSession) context.getExternalContext().getSession(true);
		// loaded = (League) session.getAttribute("league");

		// 2. load league passed through flash
		loaded = (League) flash.get("league");

		// cleaning: attribute received => delete it from session
		if (loaded != null) {
			league = loaded;
			// session.removeAttribute("league");
		} else {
			context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Błędne użycie systemu", null));
			// if (!context.isPostback()) { //possible redirect
			// context.getExternalContext().redirect("leagueList.xhtml");
			// context.responseComplete();
			// }
		}

	}

	public String saveData() {
		// no League object passed
		if (loaded == null) {
			return PAGE_STAY_AT_THE_SAME;
		}

		try {
			if (league.getId() == null) {
				// new record
				leagueDAO.create(league);
			} else {
				// existing record
				leagueDAO.merge(league);
			}
		} catch (Exception e) {
			e.printStackTrace();
			context.addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_ERROR, "wystąpił błąd podczas zapisu", null));
			return PAGE_STAY_AT_THE_SAME;
		}

		return PAGE_LEAGUE_LIST;
	}
}
