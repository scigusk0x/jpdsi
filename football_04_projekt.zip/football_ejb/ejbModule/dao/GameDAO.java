package dao;

import java.util.List;

import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import entities.Game;

//DAO - Data Access Object for Person entity
//Designed to serve as an interface between higher layers of application and data.
//Implemented as stateless Enterprise Java bean - server side code that can be invoked even remotely.

@Stateless
public class GameDAO {
	private final static String UNIT_NAME = "footballPU";

	// Dependency injection (no setter method is needed)
	@PersistenceContext(unitName = UNIT_NAME)
	protected EntityManager em;

	public void create(Game game) {
		em.persist(game);
	}

	public Game merge(Game game) {
		return em.merge(game);
	}

	public void remove(Game game) {
		em.remove(em.merge(game));
	}

	public Game find(Object id) {
		return em.find(Game.class, id);
	}

	public List<Game> getFullList() {
		List<Game> list = null;

		Query query = em.createQuery("select g from Game g");

		try {
			list = query.getResultList();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return list;
	}
}
