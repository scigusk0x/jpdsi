package dao;

import java.util.List;

import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import entities.FavouriteTeam;

//DAO - Data Access Object for Person entity
//Designed to serve as an interface between higher layers of application and data.
//Implemented as stateless Enterprise Java bean - server side code that can be invoked even remotely.

@Stateless
public class FavouriteTeamDAO {
	private final static String UNIT_NAME = "footballPU";

	// Dependency injection (no setter method is needed)
	@PersistenceContext(unitName = UNIT_NAME)
	protected EntityManager em;

	public void create(FavouriteTeam favouriteTeam) {
		em.persist(favouriteTeam);
	}

	public FavouriteTeam merge(FavouriteTeam favouriteTeam) {
		return em.merge(favouriteTeam);
	}

	public void remove(FavouriteTeam favouriteTeam) {
		em.remove(em.merge(favouriteTeam));
	}

	public FavouriteTeam find(Object id) {
		return em.find(FavouriteTeam.class, id);
	}

	public List<FavouriteTeam> getFullList() {
		List<FavouriteTeam> list = null;

		Query query = em.createQuery("select ft from FavouriteTeam ft");

		try {
			list = query.getResultList();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return list;
	}
}
