package dao;

import java.util.List;

import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import entities.FavouriteLeague;

//DAO - Data Access Object for Person entity
//Designed to serve as an interface between higher layers of application and data.
//Implemented as stateless Enterprise Java bean - server side code that can be invoked even remotely.

@Stateless
public class FavouriteLeagueDAO {
	private final static String UNIT_NAME = "footballPU";

	// Dependency injection (no setter method is needed)
	@PersistenceContext(unitName = UNIT_NAME)
	protected EntityManager em;

	public void create(FavouriteLeague favouriteLeague) {
		em.persist(favouriteLeague);
	}

	public FavouriteLeague merge(FavouriteLeague favouriteLeague) {
		return em.merge(favouriteLeague);
	}

	public void remove(FavouriteLeague favouriteLeague) {
		em.remove(em.merge(favouriteLeague));
	}

	public FavouriteLeague find(Object id) {
		return em.find(FavouriteLeague.class, id);
	}

	public List<FavouriteLeague> getFullList() {
		List<FavouriteLeague> list = null;

		Query query = em.createQuery("select fl from FavouriteLeague fl");

		try {
			list = query.getResultList();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return list;
	}
}
