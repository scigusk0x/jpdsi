package dao;

import java.util.List;
import java.util.Map;

import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import entities.League;

//DAO - Data Access Object for Person entity
//Designed to serve as an interface between higher layers of application and data.
//Implemented as stateless Enterprise Java bean - server side code that can be invoked even remotely.

@Stateless
public class LeagueDAO {
	private final static String UNIT_NAME = "footballPU";

	// Dependency injection (no setter method is needed)
	@PersistenceContext(unitName = UNIT_NAME)
	protected EntityManager em;

	public void create(League league) {
		em.persist(league);
	}

	public League merge(League league) {
		return em.merge(league);
	}

	public void remove(League league) {
		em.remove(em.merge(league));
	}

	public League find(Object id) {
		return em.find(League.class, id);
	}

	public List<League> getFullList() {
		List<League> list = null;

		Query query = em.createQuery("select l from League l");

		try {
			list = query.getResultList();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return list;
	}
	
	public List<League> getList(Map<String, Object> searchParams) {
		List<League> list = null;
		
		// 1. Build query string with parameters
		String select = "select l ";
		String from = "from League l ";
		String where = "";
		String orderby = "order by l.name asc";
		
		// search for name
		String name = (String) searchParams.get("name");
		if (name != null) {
			if (where.isEmpty()) {
				where = "where ";
			} else {
				where += "and ";
			}
			where += "l.name like :name ";
		}
		
		// ... other parameters ...
		
		// 2. Create query object
		Query query = em.createQuery(select + from + where + orderby);
		
		// 3. Set configured parameters
		if (name != null) {
			query.setParameter("name", name+"%");
		}
		
		// ... other parameters ...
		
		// 4. Execute query and retrieve list of League objects
		try {
			list = query.getResultList();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return list;
	}
}
