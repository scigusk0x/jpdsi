package entities;

import java.io.Serializable;
import jakarta.persistence.*;


/**
 * The persistent class for the favourite_league database table.
 * 
 */
@Entity
@Table(name="favourite_league")
@NamedQuery(name="FavouriteLeague.findAll", query="SELECT f FROM FavouriteLeague f")
public class FavouriteLeague implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer id;

	@Column(name="league_id")
	private Integer leagueId;

	@Column(name="user_id")
	private Integer userId;

	public FavouriteLeague() {
	}

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getLeagueId() {
		return this.leagueId;
	}

	public void setLeagueId(Integer leagueId) {
		this.leagueId = leagueId;
	}

	public Integer getUserId() {
		return this.userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

}