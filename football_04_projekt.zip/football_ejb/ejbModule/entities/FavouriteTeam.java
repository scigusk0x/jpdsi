package entities;

import java.io.Serializable;
import jakarta.persistence.*;


/**
 * The persistent class for the favourite_team database table.
 * 
 */
@Entity
@Table(name="favourite_team")
@NamedQuery(name="FavouriteTeam.findAll", query="SELECT f FROM FavouriteTeam f")
public class FavouriteTeam implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer id;

	@Column(name="team_id")
	private Integer teamId;

	@Column(name="user_id")
	private Integer userId;

	public FavouriteTeam() {
	}

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getTeamId() {
		return this.teamId;
	}

	public void setTeamId(Integer teamId) {
		this.teamId = teamId;
	}

	public Integer getUserId() {
		return this.userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

}